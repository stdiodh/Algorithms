import java.util.LinkedList;
import java.util.Queue;

public class QueueTest {

	public void sample() {
		Queue<Integer> queue = new LinkedList<>();

		System.out.println("*** poll() 메서드 테스트 ***");
		queue.add(1);
		queue.offer(2);
		queue.offer(3);
		System.out.println("큐 상태: " + queue);
		System.out.println("첫 번째 요소 제거: " + queue.poll() + ", 큐 상태: " + queue);
		System.out.println("두 번째 요소 제거: " + queue.poll() + ", 큐 상태: " + queue);
		System.out.println("세 번째 요소 제거: " + queue.poll() + ", 큐 상태: " + queue);

		System.out.println("*** peek() 메서드 테스트 ***");
		queue.offer(4);
		queue.offer(5);
		queue.offer(6);
		System.out.println("첫 번째 요소 확인: " + queue.peek() + ", 큐 상태: " + queue);
		System.out.println("첫 번째 요소 확인: " + queue.peek() + ", 큐 상태: " + queue);
		System.out.println("첫 번째 요소 확인: " + queue.peek() + ", 큐 상태: " + queue);

		System.out.println("*** remove() 메서드 테스트 ***");
		System.out.println("첫 번째 요소 제거: " + queue.remove() + ", 큐 상태: " + queue);

		System.out.println("*** clear() 메서드 테스트 ***");
		queue.clear();
		System.out.println("큐 상태: " + queue);
	}

	public static void main(String[] args) {
		QueueTest qs = new QueueTest();
		qs.sample();
	}
}
