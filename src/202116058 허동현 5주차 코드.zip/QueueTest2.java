import java.util.ArrayList;

public class QueueTest2<T> {

    // ArrayList 인스턴스 생성
    private ArrayList<T> queue = new ArrayList<>();

    // enqueue 메서드
    public void enqueue(T item) {
        queue.add(item);
    }

    // dequeue 메서드
    public T dequeue() {
        if (queue.isEmpty()) { // 큐가 비어있으면
            return null; // null을 반환하고
        }
        return queue.remove(0); // 첫 번째 요소를 제거하고 반환한다.
    }

    // isEmpty 메서드
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public static void main(String[] args) {
        QueueTest2<Integer> queue = new QueueTest2<>();
        queue.enqueue(100);
        queue.enqueue(200);
        queue.enqueue(300);
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
    }
}
