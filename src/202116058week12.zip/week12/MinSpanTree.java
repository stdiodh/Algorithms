package week12;

public class MinSpanTree {

	final static int INF = 9999; // 무한대를 의미하는 값

	// Prim 알고리즘을 이용하여 최소 신장 트리를 구한다
	public static void primMST(int[][] w, int n) {
		int[] near = new int[n];       // 각 정점에서 가장 가까운 빨간 정점
		boolean[] isblue = new boolean[n]; // 아직 선택되지 않은 파란 정점 표시
		int i, b, minval, newred;

		isblue[0] = false; // 0번 정점을 시작 정점(빨간색)으로 선택
		newred = 0;

		System.out.println("최소 신장 트리의 간선과 가중치\n");
		System.out.println("간선\t가중치");

		// 초기화: 0번 정점 외 모든 정점을 파란색으로 설정하고, 가장 가까운 빨간 정점은 0번으로 설정
		for (i = 1; i < n; i++) {
			isblue[i] = true;
			near[i] = 0;
		}

		// n-1개의 간선을 선택하여 최소 신장 트리를 구성
		for (i = 1; i <= n - 1; i++) {
			minval = INF;

			// 파란 정점들 중에서 가장 가까운 빨간 정점과의 최소 간선을 선택
			for (b = 0; b < n; b++) {
				if (isblue[b]) {
					if (w[b][near[b]] < minval) {
						minval = w[b][near[b]];
						newred = b;
					}
				}
			}

			isblue[newred] = false; // 선택된 정점을 빨간 정점으로 변경

			System.out.println(near[newred] + " - " + newred + "\t  " + w[newred][near[newred]]);

			// 새롭게 추가된 빨간 정점을 기준으로 각 파란 정점의 near 정보를 갱신
			for (b = 0; b < n; b++) {
				if (isblue[b]) {
					if (w[b][newred] < w[b][near[b]])
						near[b] = newred;
				}
			}
		}
	}

	public static void main(String[] args){
		int graph[][] = new int[][] {
				{0, 1, 5, 2, 4},
				{1, 0, 8, 9, 4},
				{5, 8, 0, 7, 6},
				{2, 9, 7, 0, 3},
				{4, 4, 6, 3, 0},
		};

		primMST(graph, 5);
	}
}
