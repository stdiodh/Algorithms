package week12;

import java.util.Scanner;

public class CoinChange{
	public static void main (String[] args){
		int[] coinValue = {500, 160, 50, 10, 5, 1};
		int i;			// 동전의 단위를 배열로 선언
		int[] numCoin;	// 사용된 각 동전의 개수를 저장할 배열
		int change;		// 거스름돈
		int count = 0;	// 사용된 동전의 총 개수

		numCoin = new int[6];  // 주의: 배열 크기가 coinValue보다 작음 (버그 있음)

		Scanner scan = new Scanner(System.in);

		for (i = 0; i < numCoin.length; i++)
			numCoin[i] = 0;

		System.out.print("거스름돈을 입력하세요[0-999]: ");

		change = scan.nextInt();

		i = 0;

		System.out.println (change + "원의 거스름돈에 대한 동전의 구성:");

		while (change > 0){
			numCoin[i] = change / coinValue[i];
			count = count + numCoin[i];
			change = change % coinValue[i];

			if (numCoin[i] > 0)
				System.out.println(coinValue[i] + "원짜리 동전 " + numCoin[i] + "개");
			i++;
		}

		System.out.println ("\n거스름돈에 사용된 동전의 총 개수: " + count);
		scan.close();
	}
}
