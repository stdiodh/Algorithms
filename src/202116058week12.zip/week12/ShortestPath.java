package week12;

public class ShortestPath {
	final static int INF = 9999; // 무한대를 의미하는 값

	// 아직 방문하지 않은 정점 중에서 최단 거리 d가 가장 작은 정점의 인덱스를 반환
	static int findMinDistance(int d[], boolean T[], int n) {
		int min = Integer.MAX_VALUE;
		int min_index = -1;

		for (int v = 0; v < n; v++) {
			if (!T[v] && d[v] <= min) {
				min = d[v];
				min_index = v;
			}
		}
		return min_index;
	}

	// 각 정점까지의 최단 거리와 경로를 출력
	static void printShortestPath(int d[], int p[], int n) {
		String sp; // 최단 경로
		int v;

		System.out.println("정점\t거리\t최단 경로");

		for (int i = 0; i < n; i++) {
			v = i;
			sp = v + "";
			while (p[v] != -1) {
				sp = p[v] + " - " + sp;
				v = p[v];
			}
			System.out.println(i + "\t" + d[i] + "\t" + sp);
		}
	}

	// Dijkstra 알고리즘
	static void dijkstra(int W[][], int src, int n) {
		int d[] = new int[n]; // d[i]: 시작 정점으로부터 i까지의 최단 거리
		boolean T[] = new boolean[n]; // T[i]: 정점 i의 처리 여부
		int p[] = new int[n]; // p[i]: i 이전의 정점 (경로 추적용)

		// 초기화
		for (int i = 0; i < n; i++) {
			d[i] = Integer.MAX_VALUE;
			T[i] = false;
			p[i] = -1;
		}
		d[src] = 0;

		// 모든 정점 처리
		for (int count = 0; count < n - 1; count++) {
			int u = findMinDistance(d, T, n); // 아직 처리되지 않은 정점 중 최소 거리 정점 선택
			T[u] = true;

			for (int v = 0; v < n; v++) {
				if (!T[v] && W[u][v] != 0 &&
						d[u] != Integer.MAX_VALUE &&
						d[u] + W[u][v] < d[v]) {
					d[v] = d[u] + W[u][v];
					p[v] = u;
				}
			}
		}
		printShortestPath(d, p, n);
	}

	public static void main(String[] args) {
		int W[][] = new int[][] {
				{0, 2, INF, INF, 7},
				{2, 0, 5, INF, 1},
				{INF, 5, 0, 4, 3},
				{INF, INF, 4, 0, 6},
				{7, 1, 3, 6, 0},
		};
		dijkstra(W, 0, 5);
	}
}
