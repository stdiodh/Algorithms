package week12; // 프로그램 7-5: 분할 배낭 문제 해결

import java.util.Scanner;

class FractionalKnapsack {
	int n = 4;				// 아이템의 수
	double weight[] = {50, 10, 25, 15};	// 각 아이템의 무게
	double value[] = {5, 60, 10, 75};		// 각 아이템의 가치
	double W = 40;			// 배낭의 용량
	double[] unitValue;	// 단위 무게당 가치

	// 아이템 수, 각 아이템의 무게, 가치, 배낭의 용량을 입력받는다
//	public void inputData() {
//		int i;
//		Scanner sc = new Scanner(System.in);
//
//		System.out.print("아이템의 개수를 입력하세요: ");
//		n = sc.nextInt();
//
//		weight = new double[n];
//		value = new double[n];
//
//		System.out.print("각 아이템의 무게를 입력하세요: ");
//		for (i = 0; i < n; i++)
//			weight[i] = sc.nextDouble();
//
//		System.out.print("각 아이템의 가치를 입력하세요: ");
//		for (i = 0; i < n; i++)
//			value[i] = sc.nextDouble();
//
//		System.out.print("배낭의 용량을 입력하세요: ");
//		W = sc.nextDouble();
//
//		sc.close();
//	}

	// 아직 선택되지 않은 아이템 중에서 단위 무게당 가치가 가장 높은 것을 찾는다
	public int getNextItem() {
		double highest = 0;
		int index = -1;

		// 단위 가치가 가장 높은 아이템의 인덱스를 반환
		for (int i = 0; i < value.length; ++i) {
			if (unitValue[i] > highest) {
				highest = unitValue[i];
				index = i;
			}
		}
		return index;
	}

	// 배낭 문제 해결: 아이템을 선택하여 배낭을 최대한 가치 있게 채운다
	public void fractionalKnapsack() {
		unitValue = new double[n]; // 단위 무게당 가치
		int i, item;

		// 각 아이템의 단위 무게당 가치를 계산
		for (i = 0; i < n; i++)
			unitValue[i] = value[i] / weight[i];

		System.out.println();

		double cW = 0; // 현재 배낭에 들어간 무게
		double cV = 0; // 현재 배낭에 들어간 총 가치

		// 단위 무게당 가치가 가장 높은 아이템을 선택
		item = getNextItem();

		// 배낭이 가득 차기 전까지, 선택한 아이템들을 계속 넣는다
		while ((item != -1) && (cW + weight[item] <= W)) {
			// 현재 아이템 전체를 배낭에 넣는다
			cW += weight[item];
			cV += value[item];
			System.out.println("아이템 " + (item + 1) + "을(를) " + weight[item] + "만큼 배낭에 넣습니다.");
			unitValue[item] = 0;  // 이미 넣은 아이템은 다시 선택되지 않도록 0으로 설정
			item = getNextItem(); // 다음 아이템 선택
		}

		// 남은 용량만큼 아이템을 쪼개어 넣는다 (분할)
		if (W - cW > 0 && item != -1) {
			System.out.println("아이템 " + (item + 1) + "을(를) " + (W - cW) + "만큼 배낭에 넣습니다.");
			cV += (unitValue[item] * (W - cW));
			cW += (W - cW);
		}

		System.out.println("\n총 가치 = " + cV + ", 총 무게 = " + cW);
	}

	public static void main(String args[]) {
		FractionalKnapsack fks = new FractionalKnapsack();

		// 데이터 입력
//		fks.inputData();

		// 분할 배낭 문제 해결
		fks.fractionalKnapsack();
	}
}
