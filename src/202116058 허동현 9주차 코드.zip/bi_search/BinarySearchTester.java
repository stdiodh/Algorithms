//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package bi_search;

import java.util.Arrays;
import java.util.Scanner;

class BinarySearchTester {
    BinarySearchTester() {
    }

    public static void main(String[] args) {
        Scanner stdIn = new Scanner(System.in);
        System.out.print("요솟수：");
        int num = stdIn.nextInt();
        int[] x = new int[num];
        System.out.println("오름차순으로 입력하세요.");
        System.out.print("x[0]：");
        x[0] = stdIn.nextInt();

        int ky;
        for(ky = 1; ky < num; ++ky) {
            do {
                System.out.print("x[" + ky + "]：");
                x[ky] = stdIn.nextInt();
            } while(x[ky] < x[ky - 1]);
        }

        System.out.print("검색할 값：");
        ky = stdIn.nextInt();
        int idx = Arrays.binarySearch(x, ky);
        if (idx < 0) {
            System.out.println("그 값의 요소가 없습니다.");
        } else {
            System.out.println(ky + "은(는) x[" + idx + "]에 있습니다.");
        }

    }
}
