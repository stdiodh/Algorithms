//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package bi_search;

class BinSearch {
    BinSearch() {
        throw new Error("Unresolved compilation problem: \n\tSyntax error on token \"7\", delete this token\n");
    }

    static int binSearch(int[] var0, int var1, int var2) {
        throw new Error("Unresolved compilation problem: \n");
    }

    public static void main(String[] var0) {
        throw new Error("Unresolved compilation problem: \n");
    }
}
