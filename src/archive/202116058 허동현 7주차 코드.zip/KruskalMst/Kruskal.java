package KruskalMst;

import java.util.*;

public class Kruskal {
	int N, M; // 그래프의 정점 수, 간선 수
	List<Edge>[] graph;
	UnionFind uf; // Union-Find 자료구조 초기화
	Edge[] tree;

	// 간선의 가중치를 기준으로 정렬하는 비교자 클래스
	static class Weight_Comparison implements Comparator<Edge> {
		public int compare(Edge e, Edge f) {
			if (e.weight > f.weight)
				return 1;
			else if (e.weight < f.weight)
				return -1;
			return 0;
		}
	}

	// Kruskal 알고리즘을 위한 생성자
	public Kruskal(List<Edge>[] adjList, int numOfEdges) {
		N = adjList.length;
		M = numOfEdges;
		graph = adjList;
		uf = new UnionFind(N);	// Union-Find 자료구조 초기화
		tree = new Edge[N - 1]; // MST를 저장할 간선 배열
	}

	// Kruskal 알고리즘을 사용하여 최소 신장 트리(MST)를 구하는 메서드
	public Edge[] mst() {
		Weight_Comparison BY_WEIGHT = new Weight_Comparison();  // 가중치 기준으로 정렬
		PriorityQueue<Edge> pq = new PriorityQueue<Edge>(M, BY_WEIGHT);  // 우선순위 큐를 사용하여 간선 정렬

		// 간선들을 우선순위 큐에 추가
		for (int i = 0; i < N; i++) {
			for (Edge e : graph[i]) {
				pq.add(e);  // 간선들을 큐에 추가
			}
		}

		int count = 0;
		// 최소 신장 트리가 완성될 때까지 간선을 선택
		while (!pq.isEmpty() && count < N - 1) {
			Edge e = pq.poll();          // 우선순위 큐에서 가장 작은 간선 선택
			int u = e.vertex;            // 시작 정점
			int v = e.adjvertex;         // 끝 정점

			// 사이클을 생성하지 않으면 간선을 트리에 추가
			if (!uf.isConnected(u, v)) {
				uf.union(u, v);          // u와 v를 같은 집합으로 합침
				tree[count++] = e;       // MST에 간선 추가
			}
		}
		return tree;  // MST 간선 배열 반환
	}
}
