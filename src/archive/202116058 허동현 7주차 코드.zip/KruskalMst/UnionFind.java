package KruskalMst;

import java.util.*;

public class UnionFind {
	protected  int[] p;  // 배열 크기 N에 따라 p[i]는 i의 부모 노드를 의미
	protected  int[] rank;

	public UnionFind(int N) {
		p = new int[N];
		rank = new int[N];
		for (int i = 0; i < N; i++) {
			p[i]    = i;  // 초기 i의 부모는 자기 자신
			rank[i] = 0;  // rank는 0으로 초기화
		}
	}
	// i의 부모 노드를 찾는 함수
	protected int find(int i) { //  경로 압축
		if ( i != p[i])
			p[i] = find(p[i]);  // 부모가 자기 자신이 아니면, 부모를 재귀적으로 찾아서 압축
		return p[i];
	}
	// i와 j가 같은 집합에 속하는지 확인하는 함수
	public boolean isConnected(int i, int j) {
		return find(i) == find(j);
	}
	// i와 j를 합치는 함수
	public void union(int i, int j) {  // Union 연산
		int iroot = find(i);
		int jroot = find(j);
		if (iroot == jroot) return;  // 이미 같은 집합에 있으면 합칠 필요 없음
		// rank가 작은 트리를 큰 트리 아래에 붙여서 트리 높이를 최소화
		if (rank[iroot] > rank[jroot])
			p[jroot] = iroot;               // iroot를 jroot의 부모로 설정
		else if (rank[iroot] < rank[jroot])
			p[iroot] = jroot;               // jroot를 iroot의 부모로 설정
		else {
			p[jroot] = iroot;  // 같으면 아무거나 부모로 설정
			rank[iroot]++;     // iroot의 rank를 1 증가
		}
	}
}
