package KruskalMst;

import java.util.*;

public class Edge {
	int vertex, adjvertex; // 시작 정점과 인접 정점
	int weight;            // 간선의 가중치

	public Edge(int u, int v, int wt) {
		vertex = u;
		adjvertex = v;
		weight = wt;
	}
}
