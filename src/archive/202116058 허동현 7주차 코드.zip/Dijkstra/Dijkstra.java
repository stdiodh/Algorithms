package Dijkstra;

import java.util.List;

public class Dijkstra {
	public int N; // 그래프 정점의 수
	List<Edge>[] graph;
	public int[] previous; // 최단 경로를 구성하는 이전 정점을 저장하기 위한 배열

	public Dijkstra(List<Edge>[] adjList) {
		N = adjList.length;
		previous = new int[N];
		graph = adjList;
	}

	public int[] shortestPath(int s) {
		boolean[] visited = new boolean[N];
		int[] D = new int[N]; // 거리 배열

		for (int i = 0; i < N; i++) { // 초기화
			visited[i] = false;
			previous[i] = -1;
			D[i] = Integer.MAX_VALUE;
		}

		previous[s] = 0; // 시작 정점 s의 이전 정점 초기화
		D[s] = 0;

		for (int k = 0; k < N; k++) { // 방문하지 않은 정점 중에서
			int minVertex = -1;       // D 배열 중 최소값을 갖는 minVertex 찾기
			int min = Integer.MAX_VALUE;

			for (int j = 0; j < N; j++) {
				if ((!visited[j]) && (D[j] < min)) {
					min = D[j];
					minVertex = j;
				}
			}

			visited[minVertex] = true;

			for (Edge e : graph[minVertex]) { // minVertex의 인접 정점들에 대해
				if (!visited[e.adjvertex]) {  // 아직 방문하지 않은 정점이라면
					int currentDist = D[e.adjvertex];
					int newDist = D[minVertex] + e.weight;

					if (newDist < currentDist) {
						D[e.adjvertex] = newDist; // 거리 갱신
						previous[e.adjvertex] = minVertex; // 최단 경로를 위해 '어디서 왔는지' 저장
					}
				}
			}
		}
		return D;
	}
}
