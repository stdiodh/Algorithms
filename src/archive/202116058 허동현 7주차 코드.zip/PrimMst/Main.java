package PrimMst;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		int[][] weight = { // [그래프 9-4-2](a) 예시 그래프
				{ 0, 9, 10, 0, 0, 0, 0},
				{ 9, 0, 0 ,10, 5, 0, 3},
				{ 10, 0, 0, 9, 7, 2, 0},
				{ 0, 10, 9, 0, 0, 4, 8},
				{ 0, 5, 7, 0, 0, 0, 1},
				{ 0, 0, 2, 4, 0, 0, 6},
				{ 0, 3, 0, 8, 1, 6, 0},
		};
		int N = weight.length;
		List<Edge>[] adjList = new List[N];
		for (int i = 0; i < N; i++) {
			adjList[i] = new LinkedList<>();
			for (int j = 0; j < N; j++) {
				if (weight[i][j] != 0) {
					Edge e = new Edge(i, j, weight[i][j]);
					adjList[i].add(e);
				}
			}
		}

		PrimMst d = new PrimMst(adjList);

		System.out.print("최소 신장 트리의 간선: ");
		int[] tree = d.mst(0);
		for (int i = 1; i < tree.length; i++) { // 최소 신장 트리의 간선 출력
			System.out.print("(" + i + "," + tree[i] + ") ");
		}
		System.out.printf("\n\n");

		// MST 가중치 합 계산
		int sum = 0;
		for (int i = 1; i < tree.length; i++) {
			for(Edge j: adjList[i]){
				if (j.adjvertex == tree[i]){
					sum += j.weight;
					break;
				}
			}
		}
		System.out.println("최소 신장 트리의 가중치 합 = " + sum);
	}
}
