package PrimMst;

import java.util.List;

public class PrimMst {
	int N; // 그래프의 정점 개수
	List<Edge>[] graph;

	public PrimMst(List<Edge>[] adjList) { // 생성자
		N = adjList.length;
		graph = adjList;
	}

	public int[] mst (int s) { // Prim 알고리즘, s는 시작 정점
		boolean[] visited = new boolean[N]; // 방문한 정점 true로 표시
		int[] D = new int[N];
		int[] previous = new int[N]; // 최소 신장 트리의 이전 정점 추적용 배열
		for(int i = 0; i < N; i++){  // 초기화
			visited[i] = false;
			previous[i] = -1;
			D[i] = Integer.MAX_VALUE;  // D[i]는 최대값으로 초기화
		}
		previous[s] = 0;  // 시작 정점 s는 이전 정점이 없으므로 0으로 초기화
		D[s] = 0;

		for(int k = 0; k < N; k++){
			int minVertex = -1;
			int min = Integer.MAX_VALUE;
			for(int j = 0; j < N; j++){  // 방문하지 않은 정점 중 D 값이 최소인 정점 찾기
				if ((!visited[j]) && (D[j] < min)){ // 방문 안 했고 D 값이 최소이면
					min = D[j];
					minVertex = j;
				}
			}
			visited[minVertex] = true;
			for (Edge i : graph[minVertex]){ // minVertex와 연결된 간선들에 대해 D 값 업데이트
				if (!visited[i.adjvertex]){  // 아직 방문하지 않은 인접 정점에 대해서만
					int currentDist = D[i.adjvertex];
					int newDist = i.weight;
					if (newDist < currentDist){
						D[i.adjvertex] = newDist; // minVertex와의 거리가 더 가까우면 D 값을 업데이트
						previous[i.adjvertex] = minVertex; // 최소 신장 트리를 위해 이전 정점 기록
					}
				}
			}
		}
		return previous; // 최소 신장 트리의 정점들 반환
	}
}
