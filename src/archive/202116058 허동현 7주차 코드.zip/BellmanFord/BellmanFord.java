package BellmanFord;

public class BellmanFord {
    public static final int INF = Integer.MAX_VALUE;
    private int D[];
    private int previous[];  // 이전 정점을 저장
    private int N;

    public BellmanFord(int numOfVertices) { // 생성자
        N = numOfVertices;
        D = new int[N];          // 최단 거리 저장
        previous = new int[N];   // 최단 경로를 저장하기 위한 배열
    }

    public void shortestPath(int s, int adjMatrix[][]) {
        for (int i = 0; i < N; i++)
            D[i] = INF;  // 거리 배열 초기화
        D[s] = 0;
        previous[s] = 0;

        for (int k = 0; k < N - 1; k++) {  // 총 N-1번 반복
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (adjMatrix[i][j] != INF) {
                        if (D[j] > D[i] + adjMatrix[i][j]) {
                            D[j] = D[i] + adjMatrix[i][j];  // 거리 갱신
                            previous[j] = i;  // i 정점을 통해 j까지 가는 것이 더 짧음
                        }
                    }
                }
            }
        }

        /* // 1번 더 반복하여 음수 사이클 존재 여부 확인
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (adjMatrix[i][j] != INF) {
                    if (D[j] > D[i] + adjMatrix[i][j])
                        System.out.println("음수 사이클 존재");
                }
            }
        }
        */
    }

    public void printPaths(int s) {   // 최단 경로 출력
        System.out.println("정점 " + s + "로부터의 최단 거리");
        for (int i = 1; i < N; i++) {
            System.out.printf("[%d, %d] = %3d", s, i, D[i]);
            System.out.println();
        }

        System.out.println();
        System.out.println("정점 0으로부터의 최단 경로");
        for (int i = 1; i < N; i++) {
            int back = i;
            System.out.print(back);
            while (back != 0) {
                System.out.print(" <- " + previous[back]);
                back = previous[back];
            }
            System.out.println();
        }
    }
}
