package week11;

public class FindMaxMin {
	public static int[] findMaxMin(int[] A, int i, int j) {
		int mid;
		int[] result = new int[2];
		int[] leftResult;
		int[] rightResult;

		if (i == j) {
			result[0] = A[i];
			result[1] = A[i];
		} else if (i == j - 1) {
			if (A[i] < A[j]) {
				result[0] = A[i];
				result[1] = A[j];
			} else {
				result[0] = A[j];
				result[1] = A[i];
			}
		} else {
			mid = (i + j) / 2;
			leftResult = findMaxMin(A, i, mid);
			rightResult = findMaxMin(A, mid + 1, j);

			result[0] = Math.min(leftResult[0], rightResult[0]);
			result[1] = Math.max(leftResult[1], rightResult[1]);
		}
		return result;
	}

	public static void main(String[] args) {
		int[] A = {24, 75, 92, 83, 61, 48, 97, 50};
		int[] answer = findMaxMin(A, 0, A.length - 1);

		System.out.println("최소값: " + answer[0]);
		System.out.println("최대값: " + answer[1]);
	}
}
