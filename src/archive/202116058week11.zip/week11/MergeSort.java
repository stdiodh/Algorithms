package week11;

public class MergeSort {
	public static void Merge(int A[], int low, int mid, int high){
		int h, i, j, k;
		int[] B = new int[high + 1]; // 부분 배열을 저장하기 위한 임시 배열

		h = low; i = low; j = mid + 1;

		while (i <= mid && j <= high) {
			if (A[i] <= A[j]) {
				B[h] = A[i];
				i = i + 1;
			} else {
				B[h] = A[j];
				j = j + 1;
			}
			h = h + 1;
		}

		if (i > mid) {
			for (k = j; k <= high; k++) {
				B[h] = A[k];
				h = h + 1;
			}
		} else {
			for (k = i; k <= mid; k++) {
				B[h] = A[k];
				h = h + 1;
			}
		}

		for (k = low; k <= high; k++) {
			A[k] = B[k];
		}
	}

	public static void MergeSort(int A[], int low, int high){
		if (low < high){
			int mid = (low + high) / 2;
			MergeSort(A, low, mid);
			MergeSort(A, mid + 1, high);
			Merge(A, low, mid, high);
		}
	}

	public static void printArray(int A[]){
		for (int i = 0; i < A.length; ++i)
			System.out.print(A[i] + " ");
		System.out.println();
	}

	public static void main(String args[]){
		int A[] = {50, 70, 25, 3, 90, 33, 4, 88};

		System.out.println("주어진 배열:");
		printArray(A);

		MergeSort(A, 0, A.length - 1);

		System.out.println("\n정렬된 배열:");
		printArray(A);
	}
}
