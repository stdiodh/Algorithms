package week11;

public class FindMaxMin1{
    public static void main(String[] args) {
        int[] numbers = {30, 50, 70, 10, 25, 100, 3, 90, 110, 33, 77, 4, 88};

        int[] result = findMinMax(numbers, 0, numbers.length - 1);

        int min = result[0];
        int max = result[1];

        System.out.println("최솟값 : " + min);
        System.out.println("최댓값 : " + max);
    }

    public static int[] findMinMax(int[] arr, int low, int high) {
        int[] result = new int[2];

        if (low == high) {
            result[0] = arr[low]; //최솟값
            result[1] = arr[high]; //최댓값
            return result;
        }
        int mid = (low + high) / 2;
        int[] leftResult = findMinMax(arr, low, mid);
        int[] rightResult = findMinMax(arr, mid + 1, high);

        result[0] = Math.min(leftResult[0], rightResult[0]);

        result[1] = Math.max(leftResult[1], rightResult[1]);

        return result;
    }
}