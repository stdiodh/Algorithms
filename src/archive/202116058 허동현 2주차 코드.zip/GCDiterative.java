public class GCDiterative {
    public static int gcdIterative(int a, int b){
        while(b != 0){
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static void main(String[] args) {
        int num1 = 24;
        int num2 = 14;

        System.out.println("반복문 방식 GCD(" + num1 + "," + num2 + ") = " + gcdIterative(num1, num2));
    }
}
