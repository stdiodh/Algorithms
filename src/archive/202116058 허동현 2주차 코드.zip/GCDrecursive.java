public class GCDrecursive {
    public static int gcdRecursive(int a, int b){
        if (b == 0){
            return a;
        }
        return gcdRecursive(b, a % b);
    }

    public static void main(String[] args){
        int num1 = 24;
        int num2 = 12;

        System.out.println("반복문 방식 GCD(" + num1 + "," + num2 + ") = " + gcdRecursive(num1, num2));
    }
}
