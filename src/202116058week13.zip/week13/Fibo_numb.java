package week13;
//동적계획법이 아닌 재귀호출

public class Fibo_numb {
	public static long fibo(int x) {
			if(x==0||x==1) {
				return 1;
			}
			return fibo(x-1)+fibo(x-2);
		}
	public static void main(String[] args) {
		System.out.println(fibo(49));
	}
}