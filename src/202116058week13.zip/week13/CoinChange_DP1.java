package week13;

import java.util.Arrays;

public class CoinChange_DP1 {
    public static void main(String[] args) {
        int[] coins = {1, 5, 10, 50, 100, 160, 500};
        int amount = 750;
        int minCoins = minCoins(coins, amount);

        System.out.println("화폐의 종류 수: " + coins.length);
        System.out.println("거스름돈 금액: " + amount);
        System.out.println("Minimum number of coins required: " + minCoins);
    }

    public static int minCoins(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, Integer.MAX_VALUE);
        dp[0] = 0;

        for (int i = 1; i <= amount; i++) {
            for (int j = 0; j < coins.length; j++) {
                if (coins[j] <= i) {
                    int subproblem = dp[i - coins[j]];
                    if (subproblem != Integer.MAX_VALUE && subproblem + 1 < dp[i]) {
                        dp[i] = subproblem + 1;
                    }
                }
            }
        }
        return dp[amount] == Integer.MAX_VALUE ? -1 : dp[amount];
    }
}
