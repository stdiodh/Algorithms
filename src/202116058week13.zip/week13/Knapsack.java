package week13;

public class Knapsack {
	static int knapSack(int C, int weight[], int value[], int n) {
		int i, j;

		int K[][] = new int[n + 1][C + 1];

		for (i = 0; i <= n; i++) K[i][0] = 0; 	// 배낭의 용량이 0일 땐 어떤 물건도 넣을 수 없음
		for (j = 0; j <= C; j++) K[0][j] = 0;  	// 물건이 없으면 어떤 용량도 채울 수 없음

		for (i = 1; i <= n; i++) {
			for (j = 1; j <= C; j++) {	// j는 배낭(현재)의 용량
				if (weight[i - 1] > j)	// 현재 i번째 물건의 무게가 현재 배낭 용량보다 크면
					K[i][j] = K[i-1][j]; // 넣을 수 없으므로 이전 결과를 그대로 사용
				else // 현재 물건을 넣을 경우와 넣지 않을 경우 중 최대값 선택
					K[i][j] =  Math.max(value[i - 1] + K[i - 1][j - weight[i - 1]], K[i - 1][j]);
			}
		}

		return K[n][C];
	}

	public static void main(String args[]) {
		int value[] = {20, 40, 30, 50};	// 물건들의 가치 배열
		int weight[] = {6, 5, 8, 4};	// 물건들의 무게 배열
		int C = 20;						// 배낭의 최대 용량
		int n = value.length;

		System.out.println("최대 가치 = " + knapSack(C, weight, value, n));
	}
}
