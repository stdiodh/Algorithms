package week13;
// bottom-up(하향식: 반복문)

public class Fibo_numb2 {
	static long[] fibo;
	final static int numb = 8;

	public static void main(String[] args) {
		fibo = new long[numb + 1];

		System.out.println("fibonacci num(" + (numb + 1) + ") = " + fibo(numb));
	}

	public static long fibo(int n) {
		fibo[0] = 1;
		fibo[1] = 1;

		for (int i = 2; i <= numb; i++) {
			fibo[i] = fibo[i - 1] + fibo[i - 2]; // 이전 두 항의 합
		}
		return fibo[n];
	}
}
