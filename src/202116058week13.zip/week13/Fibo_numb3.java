package week13;
// top-down(상향식: memoization)

public class Fibo_numb3 {
	static long fibo[];
	final static int numb = 49;

	public static void main(String[] args) {
		fibo = new long[numb + 1];

		System.out.println("fibonacci num(" + (numb + 1) + ") = " + fibonacci(numb));
	}

	public static long fibonacci(int n) {
		if (n == 0 || n == 1) {
			return 1; // 피보나치의 초기값: F(0) = F(1) = 1
		}
		if (fibo[n] != 0) {
			return fibo[n]; // 이미 계산된 값이면 그대로 반환
		}

		fibo[n] = fibonacci(n - 1) + fibonacci(n - 2); // 재귀 호출 + 메모이제이션
		return fibo[n];
	}
}
