package week13;

public class AllPairsShortestPath {

    final static int INF = 9999;

    void findAllPairShortestPath(int graph[][], int n){
        int dist[][] = new int[n][n];
        int i, j, k;

        // 초기 거리 배열 설정 (그래프 복사)
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                dist[i][j] = graph[i][j];

        // Floyd-Warshall 알고리즘
        for (k = 0; k < n; k++){
            for (i = 0; i < n; i++){
                for (j = 0; j < n; j++){
                    dist[i][j] = Math.min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
        printSolution(dist, n);
    }

    void printSolution(int dist[][], int n){
        int i, j;

        System.out.println("모든 쌍 정점들 사이의 최단 거리 행렬");

        for (i = 0; i < n; ++i){
            for (j = 0; j < n; ++j){
                if (dist[i][j] == INF)
                    System.out.print("INF ");
                else
                    System.out.print(dist[i][j] + "   ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args){
        int graph[][] = {
                {0,   4,   2,   5,   INF},
                {INF, 0,   1,   INF, 4},
                {1,   3,   0,   1,   2},
                {-2,  INF, INF, 0,   2},
                {INF, -3,  3,   1,   0}
        };

        int n = 5;

        AllPairsShortestPath a = new AllPairsShortestPath();
        a.findAllPairShortestPath(graph, n);
    }
}
