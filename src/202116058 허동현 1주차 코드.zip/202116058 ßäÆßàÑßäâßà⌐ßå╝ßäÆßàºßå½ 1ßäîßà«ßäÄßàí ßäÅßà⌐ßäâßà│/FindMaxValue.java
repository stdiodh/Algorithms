public class FindMaxValue {
    public static void main(String[] args){
        int[] numbers = {45, 20, 35, 60, 55, 10, 90, 85, 25, 75};

        int max = numbers[0];

        for(int i = 1; i < numbers.length; i++){
            if(numbers[i] > max){
                max = numbers[i];
            }
        }

        System.out.println("max[0] " + numbers[0]);
        System.out.println("배열의 최대값 : " + max);
    }
}
