public class ArraySearch {
    public static void main(String[] args) {
        int[] array = {45, 20, 60, 35, 10, 55, 90, 85, 75, 25};
        int searchValue = 85;

        int index = searchValue(array, searchValue);

        if(index != -1){
            System.out.println("찾는 값 " + searchValue + "는 배열의 " + index + "번 위치에 있습니다.");
        } else {
            System.out.println("찾는 값" + searchValue + "는 배열에 없습니다.");
        }
    }

    public static int searchValue(int[] arr, int target) {
        for(int i = 0; i < arr.length; i++){
            if(arr[i] == target){
                return i;
            }
        }
        return -1;
    }
}
